const SerialPort = require('serialport');
const os = require('os');
const nodemailer = require('nodemailer');
/*const port = new SerialPort( 'COM2',{
	baudRate: 9600,
  });*/


const port = new SerialPort('COM2',{ baudRate: 9600 }, function (err) {
if (err) {

	const obj = JSON.parse(os.networkInterfaces());
	console.log(obj);


	let msgError =
	`*******************************MICROJUNTAS********************************  \r\n	 
	Error ->  ${err.message}   (Não foi possível abrir a porta serial) \r\n
		 \r\n
		 	========== Hostname: ${os.hostname()} ========== \r\n
			========== Hostname: ${os.hostname()} ========== \r\n
		 
	`

	//ssendEmail(msgError)

	return false;


	/*return console.log(
	'/*************************************MICROJUNTAS**************************************\/' + '\r\n' +
	'> ' + '\r\n' +  
	'> 	Error ->  ', err.message  + ' (Não foi possível abrir a porta serial)' + '\r\n' + 
	'> ' + '\r\n' +
	'> ' + '\r\n' +  
	'> 			========== Hostname: ' + os.hostname() + ' ==========' + '\r\n' + 
	'>			========== Hostname: ' + os.hostname() + ' ==========' + '\r\n' + 
	'> ' + '\r\n' +
	'/**************************************************************************************\/' + '\r\n' 
	)*/
}
})


const Readline = SerialPort.parsers.Readline;
const parser = port.pipe(new Readline({ delimiter: '\r\n' }));

const express = require("express");
const socketIo = require("socket.io");
const http = require("http");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
      origin: '*',
    }
  });

var pesoAux = 0;
var cont = 0;
 
server.listen(3000, () => {
    console.log('Servidor online na porta:', server.address().port);
});

port.on('open', function () {


    port.on('data', function (res) {

		//console.log(res.toString('utf8').substring(0, 1) === 'L')

		//res.toString('utf8').substring(2, 8).length > 5 ? console.log(res.toString('utf8').substring(3, 9)) : 0

		//console.log(res.toString('utf8').substring(2, 8).length)

		//05/05
		// var peso = res.toString('utf8').substring(2, 8).replace(/(\d{1})?(\d{8})/, "$1.$2");
        var peso = res.toString('utf8').substring(0, 8).replace(/(\d{1})?(\d{8})/, "$1.$2");
		
		//if(peso != '' && res.toString('utf8').substring(2, 8).length > 5){
		if(peso != ''){	
			peso = parseFloat(peso);
			//if(peso > 0 ){
			//if(peso > 0 && peso != pesoAux){
				//console.log('Peso auxiliar:', pesoAux)
				console.log('Peso '+cont++ +':',peso );
				io.emit('serial:data',{
					Value: peso
				});
				pesoAux = peso;
				
			//}
		}
    });
});


function sendEmail(text){

	let transporter = nodemailer.createTransport({
		host: 'smtp.office365.com',
		port: 587,
		auth: {
			user: "monitoramento@microjuntas.com.br",
			pass: "Monit@2018"
		}
	})

	message = {
		from: "monitoramento@microjuntas.com.br",
		to: "igor.silva@microjuntas.com.br",
		subject: "Erro balança de pesagem: " + os.hostname(),
		text: text
   }

   transporter.sendMail(message, function(error, info){
		if (error) {
		console.log(error);
		} else {
		console.log('Email sent: ' + info.response);
		}
  	});
}